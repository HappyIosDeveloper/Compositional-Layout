//
//  ViewController.swift
//  CollectionView
//
//  Created by Ahmadreza on 4/13/23.
//

import UIKit

class ViewController: UIViewController {
    
    var collectionView: UICollectionView!
    var colors:[UIColor] = [.red, .blue, .gray, .brown, .black, .cyan, .green, .magenta, .purple]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupCollectionView()
    }
}

// MARK: - Setup Functions
extension ViewController {
    
    func setupCollectionView() {
        let layout = UICollectionViewCompositionalLayout(section: getCategorySection(size: .small))
        collectionView = UICollectionView(frame: view.frame, collectionViewLayout: layout)
        view.addSubview(collectionView)
        collectionView.register(CustomCell.self, forCellWithReuseIdentifier: CustomCell.identifier)
        collectionView.delegate = self
        collectionView.dataSource = self
        let layout2 = UICollectionViewCompositionalLayout { [self] sectionIndex, environment in
            switch sectionIndex {
            case 0 :
                return getCategorySection(size: .small)
            case 1 :
                return getCategorySection(minAnimationScale: 0.7, maxAnimationScale: 1, largeAnimationArea: 2, size: .medium)
            default:
                let size = CustomCell.Size.allCases.randomElement()!
                return getCategorySection(size: size)
            }
        }
        collectionView.setCollectionViewLayout(layout2, animated: true)
    }
    
    func getCategorySection(minAnimationScale: CGFloat = 0.9, maxAnimationScale: CGFloat = 1.0, largeAnimationArea: CGFloat = 4, size: CustomCell.Size)-> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .absolute(size.rawValue) , heightDimension: .absolute(size.rawValue))
        let group = NSCollectionLayoutGroup.vertical(layoutSize: groupSize, subitems: [item])
        group.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: CustomCell.margin, bottom: 0, trailing: CustomCell.margin)
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: CustomCell.margin, leading: 0 , bottom: 0, trailing: 0)
        section.orthogonalScrollingBehavior = .continuous
        section.visibleItemsInvalidationHandler = { (items, offset, environment) in
            items.forEach { item in
                let distanceFromCenter = abs((item.frame.midX - offset.x) - environment.container.contentSize.width / 2)
                let scale = max(maxAnimationScale - (distanceFromCenter / environment.container.contentSize.width / largeAnimationArea), minAnimationScale)
                item.transform = CGAffineTransform(scaleX: scale, y: scale)
            }
        }
        return section
    }
}

// MARK: - Collection Delegate Functions
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return colors.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CustomCell.identifier, for: indexPath) as! CustomCell
        if indexPath.section % 2 == 0 {
            cell.backgroundColor = colors[indexPath.row]
        } else {
            cell.backgroundColor = colors.reversed()[indexPath.row]
        }
        return cell
    }
}

// MARK: - Custom Cell
class CustomCell: UICollectionViewCell {
    
    static let identifier = "CustomCell"
    static let margin: CGFloat = 8
    enum Size: CGFloat, CaseIterable {
        case small = 50
        case medium = 150
        case large = 300
    }
    
    deinit {
        print("deinit")
    }
}


